# Bulldog Race V3 — диагностический прототип на пяти дорожках

Пять копий Bulldog №4 и три пресета A/B/C. Файлы не подключены к production и не используют React или Race Scenario V2.

## Готовые записи

- `DOG4_RACE_V3_PRESET_A.mp4` — Balanced, основной просмотр.
- `DOG4_RACE_V3_PRESET_B.mp4` — Overtake / Stress.
- `DOG4_RACE_V3_PRESET_C.mp4` — Long-form / Duration.

MP4 открываются двойным кликом в обычном плеере без локального сервера.

## Интерактивный запуск

Распакуйте `DOG4_RACE_V3_LAB.zip`. В папке с `index.html` выполните:

```bash
python -m http.server 8796
```

Откройте `http://127.0.0.1:8796/` в Chrome. Выберите A/B/C и нажмите Play. Есть пауза, сброс, скорость воспроизведения и перемотка. Точные параметры доступны в таблице под экраном. `file://` не поддерживается, потому что браузер загружает ES module и атласы.

`node validate.mjs` проверяет модель без браузера. `record.mjs` нужен только для повторной записи и требует Chromium, `playwright-core` и ffmpeg. Исходные ассеты не перезаписываются.
