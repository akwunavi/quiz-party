# Bulldog №4 V3 — seeded race laboratory

This is an isolated five lane diagnostic prototype. It does not import the production RaceBoard or Race Scenario V2.

## Watch the control race

Open `DOG4_V3_RANDOM_SEED_20261013.mp4` directly in a video player. The MP4 contains the full race and has no server dependency.

## Run the interactive laboratory

From this directory, run `python -m http.server 8765` and open `http://127.0.0.1:8765/` in Chrome. Select `RANDOM`, enter a uint32 seed, then click `Создать`. `Сброс` returns to the beginning of the same scenario. Presets A/B/C remain available.

Some seeds are rejected if 4,096 attempts cannot place simultaneous actions at least 0.08 of the course apart. In that case the page shows the error; enter the next seed. No event counts, types, or speed categories are changed for a rejected seed.

## Reproduce diagnostics

From this directory, run `node random_validate.mjs 10000` for the 10,000 race test. `random_results.json` records its output. The seed sequence starts at 20261013, and rejected seeds are skipped until 10,000 admissible scenarios have run. `node validate.mjs` checks the original fixed presets. `NODE_PATH=/tmp/race-preview-tools/node_modules node browser_check.mjs` was used for local Chromium playback. Recording requires Playwright Core, Chromium and FFmpeg; run `node record.mjs RANDOM 20261013` in an environment with those tools available.

The original Dog №4 clips and arena were not changed. Their existing sprite sheets are included in `assets/` for the browser lab.
