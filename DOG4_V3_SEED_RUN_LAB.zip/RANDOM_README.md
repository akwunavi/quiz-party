# Bulldog №4 V3 — seeded race laboratory

This is an isolated five lane diagnostic prototype. It does not import the production RaceBoard or Race Scenario V2.

## Watch the control race

Open `DOG4_V3_RANDOM_SEED_20261013.mp4` directly in a video player. The MP4 contains the full race and has no server dependency.

## Run the interactive laboratory

From this directory, run `python -m http.server 8765` and open `http://127.0.0.1:8765/` in Chrome. Select `RANDOM`, enter a uint32 seed, then click `Создать`. `Сброс` returns to the beginning of the same scenario. Presets A/B/C remain available.

If a seed cannot place simultaneous actions at least 0.08 of the course apart within 4,096 attempts, the lab checks the next seed. It displays both the requested and effective seed. The search is limited to 64 seed candidates. No event counts, types, or speed categories are changed within a candidate.

Open `http://127.0.0.1:8765/run_compare.html` for the short diagnostic of RUN at three speeds. The separately downloadable `DOG4_V3_RUN_SPEED_COMPARISON.mp4` contains the same 14-second comparison and does not need a server.

## Reproduce diagnostics

From this directory, run `node random_validate.mjs 10000` for the original 10,000 accepted-race test. `random_results.json` records its output. Run `node fallback_validate.mjs 10000` to test 10,000 requested seeds and the bounded fallback; results go to `fallback_results.json`. `node validate.mjs` checks the original fixed presets. `NODE_PATH=/tmp/race-preview-tools/node_modules node browser_check.mjs` was used for local Chromium playback. Recording requires Playwright Core, Chromium and FFmpeg; run `node record.mjs COMPARE` in an environment with those tools available.

The original Dog №4 clips and arena were not changed. Their existing sprite sheets are included in `assets/` for the browser lab.
