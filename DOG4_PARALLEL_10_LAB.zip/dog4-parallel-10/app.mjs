import {DOGS, RACE_END, PLACES, stateAt, summary} from './model.mjs';

const canvas=document.getElementById('race'),ctx=canvas.getContext('2d',{alpha:false});
const $=id=>document.getElementById(id);
const [manifest,layout]=await Promise.all([
  fetch('./manifest.json').then(r=>r.json()),fetch('./layout.json').then(r=>r.json())]);
const assets={};
function image(url){return new Promise((resolve,reject)=>{const im=new Image();im.onload=()=>resolve(im);im.onerror=reject;im.src=url;});}
for(const [clip,meta] of Object.entries(manifest.clips))assets[clip]=await image(meta.file);
assets.ARENA=await image('./assets/arena.png');
let t=0,playing=false,reference=0,referenceTime=0;
const timeLabel=s=>`${Math.floor(s/60)}:${(s%60).toFixed(2).padStart(5,'0')}`;
function sprite(clip,frame,x,y){
  const sw=manifest.cellWidth,sh=manifest.cellHeight,col=manifest.columns;
  ctx.drawImage(assets[clip],(frame%col)*sw,Math.floor(frame/col)*sh,sw,sh,x,y,sw,sh);
}
function draw(elapsed){
  ctx.drawImage(assets.ARENA,0,0,layout.width,layout.height);
  ctx.fillStyle='rgba(21,38,40,.82)';ctx.fillRect(0,0,layout.width,190);
  ctx.fillStyle='#fff4cc';ctx.font='bold 46px system-ui';ctx.fillText('BULLDOG №4 · 10 СЦЕНАРИЕВ',34,68);
  ctx.font='29px system-ui';ctx.fillText(`Общий таймер  ${timeLabel(elapsed)}`,35,126);
  ctx.fillText(`Финиш по фактическому пересечению · дистанция одинакова`,950,126);
  ctx.strokeStyle='rgba(255,250,217,.95)';ctx.lineWidth=5;
  ctx.beginPath();ctx.moveTo(layout.startX,205);ctx.lineTo(layout.startX,1375);
  ctx.moveTo(layout.finishX,205);ctx.lineTo(layout.finishX,1375);ctx.stroke();
  ctx.fillStyle='#fff4cc';ctx.font='bold 24px system-ui';ctx.fillText('СТАРТ',layout.startX-32,226);ctx.fillText('ФИНИШ',layout.finishX-43,226);
  for(const dog of DOGS){
    const lane=layout.laneTop+dog.index*layout.laneStep;
    ctx.fillStyle=dog.index%2 ? 'rgba(20,39,40,.23)' : 'rgba(20,39,40,.32)';
    ctx.fillRect(0,lane-96,layout.width,105);
    ctx.strokeStyle='rgba(255,247,211,.7)';ctx.lineWidth=2;
    ctx.beginPath();ctx.moveTo(layout.startX,lane+9);ctx.lineTo(layout.finishX,lane+9);ctx.stroke();
    ctx.fillStyle='#fff9dc';ctx.font='bold 27px system-ui';ctx.fillText(String(dog.index+1).padStart(2,'0'),22,lane-50);
    ctx.font='23px system-ui';ctx.fillText(dog.name,72,lane-50);
    const s=stateAt(dog,elapsed);
    const x=layout.startX+s.progress*(layout.finishX-layout.startX);
    ctx.fillStyle='rgba(28,45,35,.37)';ctx.beginPath();ctx.ellipse(x-64,lane+5,52,5,0,0,Math.PI*2);ctx.fill();
    sprite(s.clip,s.frame,x-layout.spriteAnchorX,lane-layout.spriteTopOffset);
    ctx.fillStyle='#fff9e6';ctx.font='23px system-ui';
    const phase=s.complete?'BASE_STAND':s.segment==='RUN'&&s.finished?'RUN → FINISH':s.segment;
    ctx.fillText(phase,2160,lane-54);
    ctx.font='21px system-ui';
    const completedEvents=dog.events.filter(e=>e.actionEndTime<=elapsed+1e-8).length;
    ctx.fillText(`${Math.min(100,Math.max(0,s.progress*100)).toFixed(1)}% · ${completedEvents}/${dog.events.length} событий`,2160,lane-21);
    if(s.finished){ctx.fillStyle='#fff3ad';ctx.font='bold 21px system-ui';ctx.fillText(`#${PLACES.indexOf(dog.index)+1} · ${dog.crossing.toFixed(2)} с`,2160,lane+4);}
  }
  $('clock').textContent=timeLabel(elapsed);
  $('scrub').value=String(Math.round(elapsed/RACE_END*1000));
}
function seek(seconds){t=Math.max(0,Math.min(RACE_END,Number(seconds)));reference=performance.now();referenceTime=t;draw(t);return DOGS.map(d=>stateAt(d,t));}
function pause(){playing=false;$('play').textContent='▶ Play';}
function tick(now){
  if(playing){t=Math.min(RACE_END,referenceTime+(now-reference)/1000*Number($('speed').value));draw(t);if(t>=RACE_END)pause();}
  requestAnimationFrame(tick);
}
$('play').onclick=()=>{if(playing){pause();return;}if(t>=RACE_END)seek(0);playing=true;reference=performance.now();referenceTime=t;$('play').textContent='Ⅱ Пауза';};
$('reset').onclick=()=>{pause();seek(0);};
$('speed').onchange=()=>{reference=performance.now();referenceTime=t;};
$('scrub').oninput=()=>seek(Number($('scrub').value)/1000*RACE_END);
const summaries=DOGS.map(summary);
$('table').innerHTML='<tr><th>№</th><th>Сценарий</th><th>События</th><th>До первого</th><th>Бег</th><th>STOP</th><th>Действия</th><th>RETURN</th><th>START</th><th>Пересечение</th><th>Завершение</th><th>Отставание</th></tr>'+
  summaries.map(d=>`<tr><td>${String(d.scenario).padStart(2,'0')}</td><td>${d.name}</td><td>${d.events.map(e=>e.kind+' '+Math.round(e.desiredProgress*100)+'%').join(', ')||'—'}</td><td>${d.firstEventTime?.toFixed(2)??'—'}</td><td>${d.runTime.toFixed(2)}</td><td>${d.eventStopTime.toFixed(2)}</td><td>${d.stationaryActionTime.toFixed(2)}</td><td>${d.returnTime.toFixed(2)}</td><td>${d.startTime.toFixed(2)}</td><td>${d.crossingTime.toFixed(2)}</td><td>${d.finishCompleteTime.toFixed(2)}</td><td>+${d.gapToClean.toFixed(2)}</td></tr>`).join('');
window.parallelLab={seek,reset:()=>{pause();seek(0)},stateAt:(i,time)=>stateAt(DOGS[i],time),summaries,model:DOGS,raceEnd:RACE_END,places:PLACES,ready:true};
$('status').textContent='Готово · единый clock · все 10 дорожек';
draw(0);requestAnimationFrame(tick);
