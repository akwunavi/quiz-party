// One deterministic Dog 4 motion model; all ten lanes supply only event arrays.
export const FPS = 24;
export const SCENARIOS = [
  ['CLEAN RUN', []],
  ['BUTTERFLY EARLY', [['BUTTERFLY', .20]]],
  ['BUTTERFLY LATE', [['BUTTERFLY', .70]]],
  ['SNIFF EARLY', [['SNIFF_PEE', .20]]],
  ['SNIFF LATE', [['SNIFF_PEE', .70]]],
  ['BUTTERFLY → SNIFF', [['BUTTERFLY', .25], ['SNIFF_PEE', .65]]],
  ['SNIFF → BUTTERFLY', [['SNIFF_PEE', .25], ['BUTTERFLY', .65]]],
  ['DOUBLE BUTTERFLY', [['BUTTERFLY', .25], ['BUTTERFLY', .65]]],
  ['DOUBLE SNIFF', [['SNIFF_PEE', .25], ['SNIFF_PEE', .65]]],
  ['LATE EVENT STRESS', [['BUTTERFLY', .45], ['SNIFF_PEE', .92]]],
];

const STOP = 37 / FPS;
const BUTTERFLY = 121 / FPS;
const SNIFF = 48/24 + 82/48 + 20/24 + 55/32 + 24/24;
const RETURN = 16/48 + 68/40 + 8/24 + 17/48;
const START = 1;
const BASE = .5;
const HOLD = 1.5;
const V = 1/18; // normalized course lengths / second
const RUN_JOIN = 23/24; // RUN prelude #0–10, loop #11–22, then STOP #0
const LOOP = 12/24;
const EPS = 1e-9;

const smooth = u => u*u*(3-2*u);
const smoothIntegral = u => u*u*u - .5*u*u*u*u;
const brakingIntegral = u => u - u*u*u + .5*u*u*u*u;

export const CLIPS = Object.freeze({
  BASE: {duration: Infinity, count: 1}, START: {duration: START, count: 40},
  RUN: {duration: Infinity, count: 23}, STOP: {duration: STOP, count: 37},
  BUTTERFLY: {duration: BUTTERFLY, count: 121},
  SNIFF_PEE: {duration: SNIFF, count: 229}, RETURN: {duration: RETURN, count: 109},
});

function add(segments, kind, duration, p0, p1, eventIndex = -1, data = {}) {
  const t0 = segments.length ? segments.at(-1).t1 : 0;
  const segment = {kind, t0, t1:t0+duration, p0, p1, eventIndex, ...data};
  segments.push(segment);
  return segment;
}

function alignedStopTime(runStart, nominal) {
  const first = runStart + RUN_JOIN;
  return first + Math.max(0, Math.round((nominal - first)/LOOP))*LOOP;
}

function nextStopTime(runStart, crossing) {
  const first = runStart + RUN_JOIN;
  return first + Math.max(0, Math.ceil((crossing - first - EPS)/LOOP))*LOOP;
}

export function buildDog(index) {
  const [name, schedule] = SCENARIOS[index];
  const segments = [];
  let p = 0;
  add(segments, 'BASE', BASE, p, p);
  add(segments, 'START', START, p, p + V*START/2, -1, {initial:true});
  p += V*START/2;
  let runStart = segments.at(-1).t1;
  const events = [];
  for (const [kind, desired] of schedule) {
    const eventIndex = events.length;
    const nominalStopP = desired - V*STOP/2;
    const nominalStopTime = runStart + (nominalStopP - p)/V;
    const stopTime = alignedStopTime(runStart, nominalStopTime);
    if (stopTime <= runStart + EPS || p + V*(stopTime-runStart) + V*STOP/2 >= 1)
      throw new Error(`Event ${index+1}/${eventIndex+1} cannot be placed before finish`);
    add(segments, 'RUN', stopTime-runStart, p, p+V*(stopTime-runStart));
    p = segments.at(-1).p1;
    add(segments, 'STOP', STOP, p, p+V*STOP/2, eventIndex);
    p = segments.at(-1).p1;
    const action = add(segments, kind, kind==='BUTTERFLY' ? BUTTERFLY : SNIFF, p, p, eventIndex);
    if (kind === 'SNIFF_PEE') add(segments, 'RETURN', RETURN, p, p, eventIndex);
    add(segments, 'START', START, p, p+V*START/2, eventIndex);
    p = segments.at(-1).p1;
    events.push({kind, desiredProgress:desired, actualProgress:action.p0,
      stopStartTime:stopTime, actionStartTime:action.t0, actionEndTime:action.t1});
    runStart = segments.at(-1).t1;
  }
  const crossing = runStart + (1-p)/V;
  const stopTime = nextStopTime(runStart, crossing);
  add(segments, 'RUN', stopTime-runStart, p, p+V*(stopTime-runStart), -1, {crossing});
  p = segments.at(-1).p1;
  add(segments, 'FINISH_DECELERATE', STOP, p, p+V*STOP/2);
  p = segments.at(-1).p1;
  add(segments, 'BASE', HOLD, p, p);
  const complete = segments.at(-1).t0;
  return {index, name, schedule, events, segments, crossing, complete,
    lastSegmentEnd:segments.at(-1).t1};
}

export const DOGS = SCENARIOS.map((_, i) => buildDog(i));
export const RACE_END = Math.max(...DOGS.map(d => d.lastSegmentEnd));
export const PLACES = [...DOGS].sort((a,b) => Math.abs(a.crossing-b.crossing)<1e-7
  ? a.index-b.index : a.crossing-b.crossing)
  .map(d => d.index);

function variableFrame(seconds, bands, count) {
  let t = Math.max(0, seconds);
  let index = 0;
  for (const [number, fps] of bands) {
    const duration = number/fps;
    if (t < duration - EPS) return Math.min(count-1, index+Math.floor(t*fps+EPS));
    t -= duration; index += number;
  }
  return count-1;
}

export function frameFor(segment, elapsed) {
  const t = Math.max(0, elapsed-segment.t0);
  switch(segment.kind) {
    case 'BASE': return ['BASE',0];
    case 'START': return ['START',variableFrame(t,[[24,72],[16,24]],40)];
    case 'RUN': return ['RUN', t < 11/24 ? Math.min(10,Math.floor(t*24))
      : 11 + (Math.floor((t-11/24)*24+EPS)%12)];
    case 'STOP': case 'FINISH_DECELERATE': return ['STOP',Math.min(36,Math.floor(t*24))];
    case 'BUTTERFLY': return ['BUTTERFLY',Math.min(120,Math.floor(t*24))];
    case 'SNIFF_PEE': return ['SNIFF_PEE',variableFrame(t,[[48,24],[82,48],[20,24],[55,32],[24,24]],229)];
    case 'RETURN': return ['RETURN',variableFrame(t,[[16,48],[68,40],[8,24],[17,48]],109)];
    default: throw new Error(segment.kind);
  }
}

export function stateAt(dog, elapsed) {
  const t = Math.max(0,Math.min(elapsed,RACE_END));
  const segments = dog.segments;
  let lo=0, hi=segments.length;
  while(lo<hi){const mid=(lo+hi)>>1;if(segments[mid].t1<=t+EPS)lo=mid+1;else hi=mid;}
  const s=segments[Math.min(lo,segments.length-1)];
  const u=Math.max(0,Math.min(1,(t-s.t0)/(s.t1-s.t0)));
  let p=s.p0, speed=0;
  if(s.kind==='RUN'){p=s.p0+V*(t-s.t0);speed=V;}
  else if(s.kind==='START'){p=s.p0+V*START*smoothIntegral(u);speed=V*smooth(u);}
  else if(s.kind==='STOP'||s.kind==='FINISH_DECELERATE'){
    p=s.p0+V*STOP*brakingIntegral(u);speed=V*(1-smooth(u));
  }
  const [clip,frame]=frameFor(s,t);
  return {index:dog.index, scenario:dog.name, segment:s.kind, eventIndex:s.eventIndex,
    elapsed:t, progress:p, speed, clip, frame, crossingTime:dog.crossing,
    finished:t+EPS>=dog.crossing, complete:t+EPS>=dog.complete};
}

export function summary(dog) {
  const untilCross=dog.segments.filter(s=>s.t0<dog.crossing-EPS);
  const sum=kind=>untilCross.filter(s=>s.kind===kind).reduce((x,s)=>x+s.t1-s.t0,0);
  return {scenario:dog.index+1,name:dog.name,events:dog.events,
    firstEventTime:dog.events[0]?.actionStartTime ?? null,
    runTime:untilCross.filter(s=>s.kind==='RUN').reduce((x,s)=>x+Math.min(s.t1,dog.crossing)-s.t0,0),
    eventStopTime:sum('STOP'),stationaryActionTime:sum('BUTTERFLY')+sum('SNIFF_PEE'),
    returnTime:sum('RETURN'),startTime:sum('START'),
    crossingTime:dog.crossing,finishCompleteTime:dog.complete,
    gapToClean:dog.crossing-DOGS[0].crossing};
}
