import assert from 'node:assert/strict';
import {DOGS, RACE_END, PLACES, buildDog, stateAt, summary, frameFor} from './model.mjs';

const near=(a,b,eps=1e-7)=>assert.ok(Math.abs(a-b)<eps,`${a} != ${b}`);
assert.equal(DOGS.length,10);
assert.equal(PLACES[0],0);
for(const d of DOGS){
  assert.equal(stateAt(d,0).segment,'BASE');
  assert.equal(stateAt(d,.5).segment,'START');
  near(d.segments[0].t1,.5);
  near(d.segments[1].t1,1.5);
  assert.equal(d.events.length,d.schedule.length);
  for(let i=0;i<d.segments.length-1;i++){
    near(d.segments[i].t1,d.segments[i+1].t0);
    near(d.segments[i].p1,d.segments[i+1].p0);
  }
  for(const [j,event] of d.events.entries()){
    assert.equal(event.kind,d.schedule[j][0]);
    assert.ok(Math.abs(event.actualProgress-event.desiredProgress)<.015);
    assert.equal(d.segments.filter(s=>s.eventIndex===j&&s.kind==='STOP').length,1);
    assert.equal(d.segments.filter(s=>s.eventIndex===j&&s.kind==='START').length,1);
    assert.equal(d.segments.filter(s=>s.eventIndex===j&&s.kind===event.kind).length,1);
    const action=d.segments.find(s=>s.eventIndex===j&&s.kind===event.kind);
    near(action.p0,action.p1);
    if(event.kind==='SNIFF_PEE'){
      const ret=d.segments.find(s=>s.eventIndex===j&&s.kind==='RETURN');
      assert.ok(ret);near(ret.p0,ret.p1);
    }
    const stop=d.segments.find(s=>s.eventIndex===j&&s.kind==='STOP');
    near(stateAt(d,stop.t0).speed,1/18);
    assert.ok(stateAt(d,stop.t0+.1).progress>stop.p0);
    near(stateAt(d,stop.t1).speed,0);
    assert.ok(stop.t0<event.actionStartTime);
  }
  for(const s of d.segments){
    const mid=(s.t0+s.t1)/2;
    const state=stateAt(d,mid);
    assert.equal(state.segment,s.kind);
    assert.ok(state.progress>=s.p0-1e-8&&state.progress<=s.p1+1e-8);
    const [clip,index]=frameFor(s,mid);
    assert.equal(state.clip,clip);assert.equal(state.frame,index);
    if(['BASE','BUTTERFLY','SNIFF_PEE','RETURN'].includes(s.kind))near(state.speed,0);
  }
  near(stateAt(d,d.crossing).progress,1);
  assert.ok(stateAt(d,d.crossing-1e-5).progress<1);
  const finish=d.segments.find(s=>s.kind==='FINISH_DECELERATE');
  assert.ok(finish.t0>=d.crossing-1e-8);
  assert.equal(stateAt(d,RACE_END).segment,'BASE');
  assert.equal(stateAt(d,RACE_END).complete,true);
  near(buildDog(d.index).crossing,d.crossing);
  near(stateAt(d,RACE_END).progress,stateAt(d,RACE_END).progress);
}
assert.equal(DOGS[8].events.length,2);
assert.equal(DOGS[7].events.length,2);
assert.ok(DOGS[9].events[1].actualProgress>.9);
assert.ok(DOGS[9].segments.some(s=>s.kind==='RUN'&&s.t0>DOGS[9].events[1].actionEndTime));
near(summary(DOGS[1]).gapToClean,summary(DOGS[2]).gapToClean);
near(summary(DOGS[3]).gapToClean,summary(DOGS[4]).gapToClean);
near(summary(DOGS[5]).gapToClean,summary(DOGS[6]).gapToClean);
near(summary(DOGS[1]).gapToClean,6.3125,1e-6);
near(summary(DOGS[3]).gapToClean,11.252083333333333,1e-6);

// A coarse seek and a fine stepping loop give the same state: no frame-rate accumulation.
for(const d of DOGS)for(let k=0;k<=Math.ceil(RACE_END*24);k++){
  const t=Math.min(RACE_END,k/24);
  const direct=stateAt(d,t),again=stateAt(d,t);
  near(direct.progress,again.progress);
  assert.equal(direct.segment,again.segment);
}
console.log(JSON.stringify({passed:true,lanes:DOGS.length,raceEnd:RACE_END,
  results:DOGS.map(d=>summary(d)),places:PLACES.map(i=>i+1)},null,2));
